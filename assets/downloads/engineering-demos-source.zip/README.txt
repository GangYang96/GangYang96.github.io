Gang Yang - Engineering demos

Open demos/README.html?lang=zh for the bilingual guide, or double-click demos/loan-lab/index.html, demos/message-lab/index.html and demos/gallery-lab/index.html.
No installation or API key required.

This archive includes demo source only. Homepage/video/download navigation belongs to the complete website package.
Run node demos/tests.cjs to check core calculations and algorithms.
